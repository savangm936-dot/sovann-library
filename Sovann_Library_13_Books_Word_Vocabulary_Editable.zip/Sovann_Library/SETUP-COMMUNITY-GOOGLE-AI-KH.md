# Sovann Library — Community, Google Login & Sovan AI Voice

## មុខងារថ្មី
- Community ដូច News Feed: សមាជិកបង្ហោះអត្ថបទ ឬរូបភាព (JPG, PNG, WEBP <= 1.2MB), Like និង Comment; Admin ឬម្ចាស់អាចលុប។
- ប្រកាស Community ជាសាធារណៈ; សូមកុំបង្ហោះរូប/ព័ត៌មានឯកជន។
- Google Login សម្រាប់សិស្សថ្មី តាម Google Identity Services; token ត្រូវបានផ្ទៀងផ្ទាត់នៅ Server។ គណនីចាស់អាច Log in ដោយ password រួចភ្ជាប់ Google ដែលមានអ៊ីមែលដូចគ្នា។
- Sovan AI: Browser SpeechRecognition ស្តាប់សំឡេង (បើ Browser គាំទ្រ) → ផ្ញើទៅ AI → ជម្រើសអានចម្លើយដោយ SpeechSynthesis។ គុណភាព/សំឡេងខ្មែរ អាស្រ័យ Browser និង voice ដែលបានដំឡើង។
- Chat សិស្សនិងគ្រូដើមនៅរក្សាទុក; មិនទាន់មាន group Messenger, push notification ឬ video call ក្នុង Chat ទេ។

## របៀប Host
1. Node.js 20+ ដំណើរការ `npm start` (PORT default 3000); មិនមែន GitHub Pages តែឯងទេ ព្រោះត្រូវការ Node Backend។
2. កំណត់ Environment Variables: ADMIN_EMAIL, ADMIN_PASSWORD, PUBLIC_URL, DATA_DIR (persistent mounted volume; must be writable), GOOGLE_CLIENT_ID (optional) និង AI_BASE_URL, AI_MODEL, AI_API_KEY (optional).
3. ផ្នែក Media និង data/Library JSON ត្រូវរក្សាទុកនៅ DATA_DIR ដដែល ដើម្បីឱ្យ Post/រូប/សិស្សមិនបាត់ពេល Host restart/redeploy។ បម្រុងទុក DATA_DIR ជាប្រចាំ។
4. HTTPS + ការកំណត់គោលនយោបាយឯកជនភាព តម្រូវសម្រាប់ប្រើជាមួយសិស្សពិត។

## Google Login Setup
1. ចូល Google Cloud Console → APIs & Services → Credentials → Create credentials → OAuth client ID → Web application។
2. ក្នុង **Authorized JavaScript origins** ដាក់ origin ពិតរបស់វេបសាយ HTTPS ឧ. `https://library.example.com` (មិនបញ្ចូល /path)។ សម្រាប់សាកល្បង `http://localhost:3000`។
3. កំណត់ OAuth consent screen ប្រសិនបើ Google Cloud ស្នើ និងកំណត់អ្នកប្រើសាកល្បងបើនៅ testing។
4. Copy Client ID (ឧ. `....apps.googleusercontent.com`) ដាក់ទៅ hosting variable `GOOGLE_CLIENT_ID`។ **មិនត្រូវផ្ញើ Client Secret ឬ API Key មកអ្នកដទៃ**។
5. Restart Server; បើក Profile → Google Login។ Google server-side verification via tokeninfo (suitable as starter; for high-traffic use google-auth-library local JWT verification).


## គណនី Admin (កំណត់តាម Google)
- Gmail ម្ចាស់វេបសាយ៖ `gomsavan07@gmail.com`។ នៅលើ Hosting → Environment Variables ដាក់ `ADMIN_GOOGLE_EMAIL=gomsavan07@gmail.com`។
- ដាក់ `GOOGLE_CLIENT_ID` របស់ Google Cloud Project ដូចផ្នែកខាងលើ។ បើក Google Login ហើយជ្រើស Gmail ដែលបានកំណត់នោះ។
- Server ផ្ទៀងផ្ទាត់ Google ID token, email_verified, issuer, audience និងការផុតកំណត់។ មានតែអ៊ីមែលដែលផ្ទៀងផ្ទាត់ត្រឹមត្រូវ និងដូច `ADMIN_GOOGLE_EMAIL` ទើបបានសិទ្ធិ Admin។
- បើមានគណនីធម្មតាមុនដោយអ៊ីមែលដូចគ្នា ការចូល Google របស់ម្ចាស់ពិតនឹងបិទការចូលដោយលេខសម្ងាត់ចាស់ និងបញ្ចប់ Session ចាស់ មុនផ្ដល់សិទ្ធិ Admin។
- **អ៊ីមែលតែមួយមុខមិនអាចបើក Admin បានទេ**។ គេត្រូវមានសិទ្ធិចូល Google របស់ម្ចាស់ពិត និង Google Client ID ដែលត្រឹមត្រូវ។
- កុំផ្ញើ Password, ID token, Secret, AI API Key តាម Chat។ មិនទាន់ Host មិនទាន់អាច Log in ជាសាធារណៈបាន។

## Sovan AI voice setup
- For actual AI chat configure `AI_BASE_URL`, `AI_MODEL`, `AI_API_KEY` on the Node server. Don't expose secret in browser or GitHub. Without these settings, Sovan AI still runs a limited offline dictionary demo, **not** a full AI conversation.
- Browser mic uses Web Speech API; may not work on some iPhones, browsers, or languages. Must grant microphone permission. It is **not** the same as full duplex real-time speech conversation or voice cloning.
- API calls may have usage costs.

## Security before production
Starter-level app only. Arrange independent security review, privacy/consent policy, content reporting, stronger anti-spam and moderation, image transformation/malware safeguards, backups, database transactions and monitoring before public launch. Existing ABA/manual credit workflow not automatic verification.
