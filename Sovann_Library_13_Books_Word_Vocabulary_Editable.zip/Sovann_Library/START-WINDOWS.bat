@echo off
chcp 65001 >nul
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 20 or later first: https://nodejs.org
  pause
  exit /b 1
)
echo Enter your Admin email (first run only):
set /p ADMIN_EMAIL=
echo Choose a strong password (do not share it):
set /p ADMIN_PASSWORD=
echo Opening on http://localhost:3000
node server.js
pause
