# គម្រោងថ្មី៖ មានពាក្យសព្ទ និងមេរៀនបន្ថែម

- បានបន្ថែមបញ្ជីពាក្យជប៉ុន–ខ្មែរ N5–N1 និងសៀវភៅបន្ថែម ៥ ប្រភេទ។
- ពាក្យ និងមេរៀនគំរូត្រូវបានបញ្ចូលដោយស្វ័យប្រវត្តិនៅពេលដំណើរការ Server ថ្មីលើកដំបូង ឬពេលធ្វើបច្ចុប្បន្នភាព។
- ទិន្នន័យសិស្ស/ការបង់ប្រាក់ចាស់មិនត្រូវបានកែ ឬលុបដោយការបន្ថែមពាក្យនេះទេ។ សូមធ្វើ backup មុន update ជានិច្ច។
- Admin → បន្ថែមពាក្យ តាមដៃ ឬ Bulk Paste (Kanji|Hiragana|Romaji|Khmer)។
- File `content/vocabulary-editable.csv` សម្រាប់មើល និងកែតាម Excel។ បើកែ CSV តែមួយមិនបានបង្ហោះក្នុងវេបសាយភ្លាមទេ: ត្រូវ Import តាម Admin ឬកែ `content/vocabulary.json` ហើយ restart Server។
- ផ្នែកខ្លះជាឧទាហរណ៍សម្រាប់សាកល្បង មិនទាន់ជាសៀវភៅពេញ ឬបញ្ជី JLPT ផ្លូវការទេ។ សូមពិនិត្យការបកប្រែមុនប្រើបោះពុម្ព។
- ប្រសិនបើប្រើ Docker ត្រូវរក្សា persistent volume `data/` ពេល update។

---

# បណ្ណាល័យ ជុំ សុវណ្ណ — CHUM SOVANN ONLINE LIBRARY

**កញ្ចប់វេបសាយពេញមួយគម្រោងសម្រាប់យកទៅ Host ដោយខ្លួនឯង។** មិនមែនត្រឹមតែរូបគំរូ HTML ទេ។ មាន Node.js backend, ទិន្នន័យនៅ Server, ការចុះឈ្មោះ/ចូលគណនី, Admin Panel និងប្រព័ន្ធសមាជិកភាព។

## បើកភ្លាមៗលើកុំព្យូទ័រ

ត្រូវមាន Node.js **20 ឬថ្មីជាងនេះ** (ណែនាំ Node 22 LTS)។ មិនត្រូវ npm install package បន្ថែមទេ។

1. បើក folder គម្រោងនេះក្នុង Terminal / PowerShell។
2. កំណត់អ៊ីមែល និងលេខសម្ងាត់ Admin នៅ Environment Variables។ **កុំសរសេរ password ក្នុងឯកសារ index.html ឬចែករំលែកឱ្យគេ**។
3. បើក `npm start` ហើយចូល `http://localhost:3000`។

Windows PowerShell:

```powershell
$env:ADMIN_EMAIL="your-email@example.com"
$env:ADMIN_PASSWORD="CHANGE-THIS-TO-A-LONG-UNIQUE-PASSWORD"
npm start
```

Mac / Linux:

```bash
export ADMIN_EMAIL="your-email@example.com"
export ADMIN_PASSWORD="CHANGE-THIS-TO-A-LONG-UNIQUE-PASSWORD"
npm start
```

Admin ត្រូវបានបង្កើតតែពេល Server ចាប់ផ្តើមដំបូង ហើយមិនមាន Admin password លំនាំដើមក្នុង ZIP ទេ។ បន្ទាប់មកចូលទំព័រ `គណនី` → Log in ដោយ Email / Password ដែលបានកំណត់ ហើយចូល `⚙️ ផ្ទាំង Admin`។

## កែពាក្យសព្ទ និងមេរៀនដោយខ្លួនឯង

1. ចូលជា Admin។
2. បើកម៉ឺនុយ **⚙️ ផ្ទាំង Admin**។
3. ផ្នែក **បន្ថែមពាក្យសព្ទ** → ជ្រើសសៀវភៅ → បំពេញ Kanji, Hiragana, Romaji, បកប្រែខ្មែរ, ឧទាហរណ៍ → ចុច **បន្ថែមពាក្យ**។
4. ផ្នែក **បន្ថែមមេរៀន** → ជ្រើសសៀវភៅ → វាយមេរៀន → រក្សាទុក។
5. ចង់បញ្ចូលពាក្យច្រើន? ប្រើផ្នែក **បន្ថែមពាក្យច្រើនបន្ទាត់** ដោយមួយបន្ទាត់៖ `Kanji|Hiragana|Romaji|អត្ថន័យខ្មែរ`។ អាចបញ្ចូលបានរហូតដល់ 250 ពាក្យមួយលើក។ ផ្នែក **បង្កើតសៀវភៅថ្មី** ក៏មានផងដែរ។
6. ផ្នែក **កែឈ្មោះសៀវភៅ** អាចប្ដូរឈ្មោះ និងរូបគម្រប។ រូបភាពបញ្ចូលពី iPhone ឬកុំព្យូទ័រ (PNG/JPG/WebP; ណែនាំឱ្យបង្រួមតិចជាង 1MB)។
7. តម្លៃសមាជិកភាព ម៉ោងរៀន Link ABA PayWay និង Link Video Room អាចកែក្នុងផ្ទាំង Admin។

## អ្វីដែលដំណើរការបាន

- រូបរាងស្រដៀងគំរូ ពណ៌ស្វាយ / សាគូរ៉ា / កាតសៀវភៅ; Responsive iPhone, Android, Windows/Mac។
- ម៉ឺនុយមួយ ទំព័រមួយ (ទំព័រដើម សៀវភៅ 10 ក្បាល ពាក្យសព្ទ វចនានុក្រម ប្រឡង N5–N1 ហាង កាបូបលុយ Chat គណនី និង Admin)។
- Login / Sign up ដោយអ៊ីមែល និងលេខសម្ងាត់បានពិត ហើយ Server រក្សាទុក។ Admin មើលសៀវភៅទាំងអស់ដោយឥតគិតថ្លៃ។
- សៀវភៅ N5 មួយក្បាលបើកឥតគិតថ្លៃ; សៀវភៅផ្សេងជាប់សោ។ មាតិកាគ្រាន់តែ **ពាក្យសព្ទ/មេរៀនគំរូ** មិនទាន់មានពាក្យរាប់ពាន់ ឬសៀវភៅពេញលេញទេ។
- វចនានុក្រមបង្ហាញតែពាក្យនៅសៀវភៅដែលអ្នកមានសិទ្ធិអាន។
- ប្រឡង JLPT គំរូ 4 សំណួរតាមកម្រិត មានពិន្ទុ និង Timer 30 វិនាទី (មិនមែនប្រឡងផ្លូវការ)។
- ហាងទំនិញ គណនាតម្លៃ កន្ត្រក ទិញដោយ Credit, រក្សាបញ្ជាទិញលើ Server។
- ABA QR ពិត **ដែលម្ចាស់បានផ្តល់** នៅទំព័រ Top Up និង Payment Link ផ្តល់ដោយម្ចាស់។ ក្រោយសិស្សបង់ Admin ពិនិត្យ ABA ដោយផ្ទាល់ហើយអនុម័ត Credit។
- ទិញគម្រោងដោយ Credit: **$2.50 ខែ / $23.99 ឆ្នាំ / $35 មួយជីវិត**។ ១ខែ / ១ឆ្នាំផុតកំណត់ដោយការពិនិត្យលើ Server; មួយជីវិតគ្មានថ្ងៃផុតកំណត់។
- Chat រវាងគ្រូ Admin និងសិស្សដែលមានគណនីដោយ Server; សារត្រូវបានរក្សាទុក (refresh ប្រហែល 12 វិនាទី)។
- Sovan AI **offline demo** សម្រាប់ឆ្លើយតាមពាក្យសព្ទ និងសំណួរមួយចំនួន, Web Speech នៅ Browser ដែលគាំទ្រ។
- បើក Video Room link ពី Admin កំណត់ (មិនទាន់មានវីដេអូខលផ្ទាល់ខ្លួន)។

## ត្រូវភ្ជាប់សេវាបន្ថែម មុនប្រើការងារពិត

**កុំអះអាងថាមុខងារទាំងនេះរួចរាល់**៖

- Google/Apple Sign in: ប៊ូតុងបង្ហាញជាគំរូបិទ មិនទាន់មាន OAuth / Apple Developer setup។ Email/password login ដំណើរការ។
- ABA PayWay **Auto Top Up / Auto Renewal**: មិនទាន់ភ្ជាប់ API។ Payment Link ពិតអាចមានចំនួនថេរ និងថ្ងៃផុតកំណត់។ ចុចទៅ ABA មិនធ្វើឱ្យ Credit កើនស្វ័យប្រវត្តិទេ។ Admin ត្រូវផ្ទៀងផ្ទាត់ប្រាក់ពិតមុនអនុម័ត។
- Sovan AI សន្ទនាឆ្លាតទូទៅ និងបង្កើតរូបភាព: ត្រូវការសេវា AI ផ្សេង (API ជាខាង Server)។ កំណត់ `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` សម្រាប់ OpenAI-compatible Chat Completions endpoint ប្រសិនបើមានអ្នក Host ដែលចេះភ្ជាប់។ គ្មាន AI image API ក្នុងកញ្ចប់នេះ។
- Clone សំឡេងផ្ទាល់ខ្លួន: មិនទាន់អនុវត្តទេ ហើយត្រូវមានសេវាសំឡេងជាពិសេស។
- ការដក Credit ទៅធនាគារ: មិនមាន; ត្រូវមាន payout API និងលក្ខខណ្ឌច្បាប់/ហិរញ្ញវត្ថុ មុនអនុញ្ញាតការដក។
- Full production security: គួរបន្ថែមការផ្ទៀងផ្ទាត់ Email/2FA, Backups, Monitoring, Anti-Spam, Privacy Policy, Refund/Cancellation Policy, Audit Trail។ បច្ចុប្បន្នជា **deployable starter** មិនមែន e-commerce system ដែលបានបញ្ជាក់សុវត្ថិភាពសម្រាប់ការផ្សាយទូលំទូលាយ។

## Hosting លើ Internet

សេវា Host ត្រូវគាំទ្រ **Node.js Server 20+**, HTTPS និង **Persistent Storage** សម្រាប់ folder `data/`។ GitHub Pages តែឯង **មិនអាចដំណើរការ Node Backend** (សមាជិកភាព, Chat, Credit) បានទេ។ ប្រើ Node-capable host (ជាឧ. Render/Railway/VPS/អ្នក Host ផ្ទាល់)។

ផ្ញើ ZIP នេះឱ្យអ្នក Host ហើយប្រាប់ថា៖

- Build: មិនចាំបាច់ build; គ្មាន npm dependencies។
- Start command: `npm start`
- PORT: Host កំណត់ស្វ័យប្រវត្តិ ឬ `PORT=3000`
- Environment: `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `PUBLIC_URL=https://your-domain.example` (optional for future)
- `DATA_DIR` = ផ្លូវទៅ persistent disk (ឧ. `/var/data/sovann-library`) **ត្រូវ mount persistent disk** មុនចុះឈ្មោះសិស្ស ឬទទួលប្រាក់។
- ប្រើ HTTPS; កុំអនុញ្ញាតឱ្យ public ចូល directory `data/`; នេះមិនស្ថិតក្នុង `public/` ទេ។
- Back up `data/library.json` ជាប្រចាំ និងកុំ upload file នេះទៅ GitHub សាធារណៈ។
- រូបគម្របដែលបញ្ចូលទៅ `public/assets/uploads/` ក៏ត្រូវមាន storage ដែលរក្សាទុកបាន (សម្រាប់ platforms ephemeral ត្រូវធ្វើ persistent volume/storage ទៀត)។
- រូប ABA QR ត្រូវបានចម្លងពីរូបដែលម្ចាស់ផ្តល់ ឲ្យប្រើទទួលប្រាក់; ផ្ទៀងផ្ទាត់ក្នុង app ABA ពិតមុនប្រើជាសាធារណៈ។

### SEO / Google Search

- រួចរាល់ title, description, Open Graph, `robots.txt` និងរូបសញ្ញា។
- បន្ទាប់ពី Host, យក URL ជាក់ស្តែងដាក់ក្នុង Google Search Console និង Submit sitemap (បង្កើតដោយ Host តាមដូមែនជាក់ស្តែង)។
- Google មិនធានាថាស្វែងរកឃើញភ្លាម ឬបានចំណាត់ថ្នាក់ខ្ពស់ទេ។
- រូប Profile របស់សិស្ស និង Admin មិនត្រូវក្លាយជាព័ត៌មាន public ក្នុង Search ដោយអត់ការយល់ព្រម។

### សុវត្ថិភាពខ្លីៗ

**មិនត្រូវបញ្ចូល Secret Key របស់ ABA/AI នៅខាង Frontend ឬក្នុង GitHub Public repo។** Login មានការការពារពាក្យសម្ងាត់ដោយ scrypt, session cookie HttpOnly, same-origin POST និង rate limiting មូលដ្ឋាន; ទោះយ៉ាងណា សូមឱ្យអ្នកជំនាញធ្វើ security review មុនប្រើដោយសិស្សជាច្រើន។

---

ចំណងជើង «ដោះសោភាសា» និងពាក្យគំរូត្រូវបានសរសេរដោយកញ្ចប់នេះ។ បងអាចកែបន្ថែមពាក្យរបស់បងតាម Admin ដោយមិនចាំបាច់កូដ។
