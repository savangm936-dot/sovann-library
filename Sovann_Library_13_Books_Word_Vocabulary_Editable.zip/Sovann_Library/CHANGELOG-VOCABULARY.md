# Vocabulary update

The sample glossary is expanded with a curated learning list, preserving the original small glossary and not overwriting existing admin-edited content.

Book levels have lesson starter paragraphs with Japanese and Khmer translation. This is not a complete textbook or an official JLPT word list.

Start: `npm start`, then open `http://localhost:3000`. Admin is created by specifying `ADMIN_EMAIL` and `ADMIN_PASSWORD` before first start; no default password.
