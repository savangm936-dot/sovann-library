'use strict';
// Sovann Library: no-dependency Node.js 20+ server. Demo + working server-side manual payment workflow.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ROOT=__dirname,PUBLIC=path.join(ROOT,'public'),DATA=process.env.DATA_DIR?path.resolve(process.env.DATA_DIR):path.join(ROOT,'data');
const DB=path.join(DATA,'library.json'),MEDIA=path.join(DATA,'media'),PORT=Number(process.env.PORT||3000);
fs.mkdirSync(DATA,{recursive:true});fs.mkdirSync(MEDIA,{recursive:true});
const iso=()=>new Date().toISOString(),id=()=>crypto.randomUUID();
const clean=(v,n=300)=>String(v??'').trim().slice(0,n);
const hash=(v,salt=crypto.randomBytes(16).toString('hex'))=>salt+':'+crypto.scryptSync(v,salt,64).toString('hex');
const match=(pw,record)=>{if(!record)return false;let [s,h]=record.split(':');let buf=crypto.scryptSync(pw,s,64);return h.length===128&&crypto.timingSafeEqual(buf,Buffer.from(h,'hex'))};
const seedWords={
N5:[['私','わたし','watashi','ខ្ញុំ'],['あなた','あなた','anata','អ្នក'],['先生','せんせい','sensei','គ្រូ'],['学生','がくせい','gakusei','សិស្ស ឬ និស្សិត'],['学校','がっこう','gakkou','សាលារៀន'],['本','ほん','hon','សៀវភៅ'],['水','みず','mizu','ទឹក'],['食べる','たべる','taberu','ញ៉ាំ'],['飲む','のむ','nomu','ផឹក'],['行く','いく','iku','ទៅ'],['来る','くる','kuru','មក'],['見る','みる','miru','មើល'],['大きい','おおきい','ookii','ធំ'],['小さい','ちいさい','chiisai','តូច'],['今日','きょう','kyou','ថ្ងៃនេះ'],['明日','あした','ashita','ថ្ងៃស្អែក'],['昨日','きのう','kinou','ម្សិលមិញ'],['日本語','にほんご','nihongo','ភាសាជប៉ុន'],['友達','ともだち','tomodachi','មិត្តភក្តិ'],['家','いえ','ie','ផ្ទះ']],
N4:[['経験','けいけん','keiken','បទពិសោធន៍'],['旅行','りょこう','ryokou','ដំណើរកម្សាន្ត'],['必要','ひつよう','hitsuyou','ចាំបាច់'],['約束','やくそく','yakusoku','ការសន្យា'],['説明','せつめい','setsumei','ការពន្យល់'],['準備','じゅんび','junbi','ការត្រៀម'],['連絡','れんらく','renraku','ការទាក់ទង'],['便利','べんり','benri','ងាយស្រួល'],['残念','ざんねん','zannen','គួរឱ្យស្តាយ'],['文化','ぶんか','bunka','វប្បធម៌']],
N3:[['環境','かんきょう','kankyou','បរិស្ថាន'],['原因','げんいん','genin','មូលហេតុ'],['結果','けっか','kekka','លទ្ធផល'],['判断','はんだん','handan','ការវិនិច្ឆ័យ'],['提案','ていあん','teian','សំណើ'],['努力','どりょく','doryoku','ការខិតខំ'],['関係','かんけい','kankei','ទំនាក់ទំនង'],['状況','じょうきょう','joukyou','ស្ថានភាព'],['可能','かのう','kanou','អាចធ្វើបាន'],['影響','えいきょう','eikyou','ឥទ្ធិពល']],
N2:[['制度','せいど','seido','ប្រព័ន្ធ ឬ របប'],['課題','かだい','kadai','បញ្ហាប្រឈម'],['傾向','けいこう','keikou','និន្នាការ'],['対策','たいさく','taisaku','វិធានការឆ្លើយតប'],['評価','ひょうか','hyouka','ការវាយតម្លៃ'],['実施','じっし','jisshi','ការអនុវត្ត'],['認識','にんしき','ninshiki','ការយល់ដឹង'],['解決','かいけつ','kaiketsu','ការដោះស្រាយ'],['支援','しえん','shien','ការគាំទ្រ'],['維持','いじ','iji','ការរក្សា']],
N1:[['概念','がいねん','gainen','គោលគំនិត'],['顕著','けんちょ','kencho','លេចធ្លោ'],['妥当','だとう','datou','សមហេតុផល'],['措置','そち','sochi','វិធានការ'],['推進','すいしん','suishin','ការជំរុញ'],['促進','そくしん','sokushin','ការលើកកម្ពស់'],['検討','けんとう','kentou','ការពិចារណា'],['構築','こうちく','kouchiku','ការកសាង'],['適応','てきおう','tekiou','ការសម្របខ្លួន'],['慎重','しんちょう','shinchou','ប្រុងប្រយ័ត្ន']]
};
const lvls=['N5','N4','N3','N2','N1'];
function fresh(){
 const books=lvls.map((lvl,i)=>({id:'vol'+(i+1),level:lvl,title:'ដោះសោភាសា',volume:i+1,subtitle:'សៀវភៅភាសាជប៉ុន '+lvl,free:i===0,color:['#e84991','#2685d8','#22aa73','#f0932e','#8739c8'][i],description:'សៀវភៅសិក្សាភាសាជប៉ុន '+lvl+' — ពាក្យសព្ទ និងមេរៀនគំរូ ដែលអាចបន្ថែមដោយ Admin',words:seedWords[lvl].map((a,j)=>({id:id(),kanji:a[0],reading:a[1],romaji:a[2],khmer:a[3],example:j===0?'日本語を勉強します。':'',translation:j===0?'ខ្ញុំរៀនភាសាជប៉ុន។':''})),lessons:[{id:id(),title:'មេរៀនទី១ — '+lvl,body:'សូមអានពាក្យសព្ទ ប្រយោគឧទាហរណ៍ ហើយសាកល្បងលំហាត់។\nこの本で日本語を勉強しましょう。\nតោះរៀនភាសាជប៉ុនតាមសៀវភៅនេះ។'}]}));
 const extras=[['grammar','សៀវភៅវេយ្យាករណ៍','文法'],['conversation','សៀវភៅសន្ទនា','会話'],['kanji','សៀវភៅសរសេរ Kanji','漢字'],['dictionary','វចនានុក្រមជប៉ុន–ខ្មែរ','辞書'],['exams','សៀវភៅលំហាត់ JLPT','試験']];
 extras.forEach(([b,t,j],i)=>books.push({id:b,level:'EXTRA',title:t,volume:6+i,subtitle:j,free:false,color:['#8257da','#27a69a','#e65b74','#5884a0','#c89129'][i],description:'សៀវភៅគំរូ អ្នកគ្រប់គ្រងអាចបន្ថែមមេរៀន និងពាក្យដោយខ្លួនឯង។',words:[],lessons:[{id:id(),title:'មេរៀនគំរូ',body:'សូមបន្ថែមខ្លឹមសារផ្ទាល់ខ្លួនក្នុង Admin Panel។'}]}));
 return {version:1,users:[],sessions:[],books,topups:[],walletTx:[],orders:[],chats:[],products:[{id:'p1',name:'សៀវភៅកត់ត្រា',price:2.5,stock:30,emoji:'📒'},{id:'p2',name:'ផ្លែប៉ោម',price:2.5,stock:30,emoji:'🍎'},{id:'p3',name:'ចេក',price:1.2,stock:30,emoji:'🍌'},{id:'p4',name:'ការ៉ុត',price:1.5,stock:30,emoji:'🥕'},{id:'p5',name:'សាឡាត់',price:1.8,stock:30,emoji:'🥬'}],config:{brand:'បណ្ណាល័យ ជុំ សុវណ្ណ',classHours:'៣:៣០–៩:៣០ (សូមបញ្ជាក់ព្រឹក/ល្ងាច)',paywayLink:'https://link.payway.com.kh/ABAPAYdj5841653',teacher:'Sovan Sensei',videoRoom:'',about:'រៀនភាសាជប៉ុនពី N5 ដល់ N1។ សៀវភៅ និងមេរៀនដើម រៀបចំដោយ Sovan Sensei។',prices:{monthly:2.5,yearly:23.99,lifetime:35}}};
}
let db=fs.existsSync(DB)?JSON.parse(fs.readFileSync(DB,'utf8')):fresh();
db.posts=Array.isArray(db.posts)?db.posts:[];db.media=Array.isArray(db.media)?db.media:[];
function save(){let tmp=DB+'.tmp';fs.writeFileSync(tmp,JSON.stringify(db,null,2));fs.renameSync(tmp,DB)}
if(!fs.existsSync(DB))save();
// Vocabulary v2: fill existing or new database with original curated sample content.
// Never overwrite admin edits, existing users, receipts, membership or personal data.
function seedBookVocabulary(){
 const vocab=JSON.parse(fs.readFileSync(path.join(ROOT,'content','vocabulary.json'),'utf8'));
 const lessons=JSON.parse(fs.readFileSync(path.join(ROOT,'content','lessons.json'),'utf8'));
 let changed=false;
 for(const book of db.books){
  book.words=Array.isArray(book.words)?book.words:[];
  book.lessons=Array.isArray(book.lessons)?book.lessons:[];
  const key=book.level==='EXTRA'?book.id:book.level;
  const seen=new Set(book.words.map(w=>String(w.kanji)+'|'+String(w.reading)));
  for(const w of (vocab[key]||[])){
   const val=String(w.kanji)+'|'+String(w.reading);
   if(seen.has(val))continue;
   book.words.push({...w,id:id(),example:'',translation:''});seen.add(val);changed=true;
  }
  const existingTitles=new Set(book.lessons.map(l=>l.title));
  (lessons[key]||[]).forEach((l,i)=>{
   const title='មេរៀនទី'+(i+2)+' — '+l.title;
   if(!existingTitles.has(title)){book.lessons.push({id:id(),title,body:l.body});existingTitles.add(title);changed=true;}
  });
 }
 if(db.version<2){db.version=2;changed=true}
 if(changed)save();
}
seedBookVocabulary();

// Vocabulary imported from the author's two DOCX documents. Never overwrite edits.
function seedImportedBooks(){
 const file=path.join(ROOT,'content','imported-vocabulary.json');
 if(!fs.existsSync(file))return;
 const imported=JSON.parse(fs.readFileSync(file,'utf8'));
 let changed=false;
 db.sourceImports=db.sourceImports||{};
 for(const level of ['N5','N4']){
  if(db.sourceImports[level]==='docx-import-2026-11-19')continue;
  const b=db.books.find(b=>b.level===level);if(!b)continue;
  b.words=Array.isArray(b.words)?b.words:[];
  const already=new Set(b.words.map(w=>String(w.kanji)+'|'+String(w.reading)));
  for(const w of imported[level]||[]){
   const k=String(w.kanji)+'|'+String(w.reading);
   if(already.has(k))continue;
   b.words.push({...w,id:id()});already.add(k);changed=true;
  }
  db.sourceImports[level]='docx-import-2026-11-19';changed=true;
 }
 if(changed)save();
}
seedImportedBooks();
// The three user-requested interactive books. Same Admin editor as JLPT volumes.
function seedThreeFocusedBooks(){
 const defs=[
  {id:'sovann-dictionary-volume',title:'ដោះសោភាសា — វចនានុក្រម',subtitle:'វចនានុក្រមជប៉ុន–ខ្មែរ · 検索',color:'#3181bc',description:'ពាក្យនាំចូលពី Word N5 និង N4។ មានសម្គាល់ប្រភពពាក្យដែលត្រូវពិនិត្យ។ Admin អាចបន្ថែម និងកែបាន។'},
  {id:'sovann-grammar-volume',title:'ដោះសោភាសា — វេយ្យាករណ៍',subtitle:'គន្លឹះទម្រង់វេយ្យាករណ៍ · 文法',color:'#a46bdb',description:'ពន្យល់ទម្រង់វេយ្យាករណ៍ និងការបំបែកកិរិយាសព្ទ។ សរសេរជាមេរៀនដើមសម្រាប់សាកល្បង; Admin អាចកែបន្ថែម។'},
  {id:'sovann-kanji-volume',title:'ដោះសោភាសា — កានជី',subtitle:'ការអាន និងសរសេរ漢字',color:'#dd7778',description:'ហាត់អក្សរកានជី ការអាន និងអត្ថន័យ។ អាចបន្ថែម Kanji តាម Admin។'}
 ];
 const grammar=[
  ['N5 · ～です / ～ではありません','នាម + です = ជា / គឺ។\nわたしは がくせいです。 — ខ្ញុំជាសិស្ស។\nនាម + ではありません = មិនមែនជា។\nわたしは せんせいではありません。 — ខ្ញុំមិនមែនជាគ្រូទេ។'],
  ['N5 · ～ます / ～ません','កិរិយាសព្ទទម្រង់ ます សម្រាប់និយាយគួរសម។\nたべます = ញ៉ាំ, たべません = មិនញ៉ាំ។\nまいにち 日本語を べんきょうします。 — ខ្ញុំរៀនភាសាជប៉ុនរាល់ថ្ងៃ។'],
  ['N5 · ～ました / ～ませんでした','កិរិយាសព្ទអតីតកាលគួរសម៖ ます → ました។\nきのう ほんを よみました。 — ម្សិលមិញខ្ញុំបានអានសៀវភៅ។'],
  ['N5 · 助詞 は・が・を・に・で','は = ប្រធានបទ, が = អ្នក/អ្វីដែលត្រូវសម្គាល់, を = កម្មបទ, に = គោលដៅ/ពេលវេលា, で = ទីកន្លែងកើតសកម្មភាព។\nがっこうで べんきょうします。 — រៀននៅសាលា។'],
  ['N5 · い-គុណនាម / な-គុណនាម','おおきい いえ — ផ្ទះធំ (い-គុណនាម)។\nしずかな へや — បន្ទប់ស្ងប់ (な-គុណនាម)។'],
  ['N4 · ～たことがある','ទម្រង់た + ことがある = ធ្លាប់ធ្វើអ្វីមួយ។\nにほんに いったことがあります。 — ខ្ញុំធ្លាប់ទៅជប៉ុន។'],
  ['N4 · ～たり～たりする','ទម្រង់た + り + ទម្រង់た + り + する = រាយឧទាហរណ៍សកម្មភាព។\nほんを よんだり、おんがくを きいたりします。 — អានសៀវភៅ និងស្ដាប់តន្ត្រីជាដើម។'],
  ['N4 · ～なければならない','ないទម្រង់កាត់ い + ければならない = ត្រូវតែធ្វើ។\nべんきょうしなければなりません。 — ត្រូវតែរៀន។'],
  ['N4 · ～てもいい / ～てはいけない','ទម្រង់て + もいい = អនុញ្ញាត; ទម្រង់て + はいけない = ហាម។\nここに すわってもいいです。 — អាចអង្គុយទីនេះបាន។'],
  ['N4 · ～そうです','កិរិយាសព្ទទម្រង់ますដក ます + そうです = ហាក់ដូចជានឹង...\nあめが ふりそうです。 — ហាក់ដូចជានឹងភ្លៀង។'],
  ['កិរិយាសព្ទក្រុមទី១ · ます形','កិរិយាសព្ទក្រុមទី១ ប្តូរសំឡេងចុងក្រោយជួរ u ទៅ i ហើយដាក់ ます។\nかく → かきます, のむ → のみます, はなす → はなします។\nករណីលើកលែង៖ ある → あります។'],
  ['កិរិយាសព្ទក្រុមទី២ · ます形','កិរិយាសព្ទក្រុមទី២ ភាគច្រើនលុប る រួចបន្ថែម ます។\nたべる → たべます, みる → みます, おきる → おきます។'],
  ['កិរិយាសព្ទក្រុមទី៣ · ます形','する → します, くる → きます។\nべんきょうする → べんきょうします។'],
  ['N3 · ～ようにする','ទម្រង់វចនានុក្រម / ない + ようにする = ខិតខំធ្វើ ឬប្រយ័ត្នមិនឱ្យធ្វើ។\nまいにち 日本語を よむようにしています。 — ខ្ញុំព្យាយាមអានភាសាជប៉ុនរាល់ថ្ងៃ។'],
  ['N3 · ～わけではない','～わけではない = មិនមែនថា...ទាំងស្រុងទេ។\n日本語が きらいなわけではありません。 — មិនមែនថាខ្ញុំស្អប់ភាសាជប៉ុនទេ។']
 ];
 const kanji=[
  ['日','にち / ひ','ថ្ងៃ'],['月','げつ / つき','ខែ / ព្រះចន្ទ'],['火','か / ひ','ភ្លើង'],['水','すい / みず','ទឹក'],['木','もく / き','ដើមឈើ'],['金','きん / かね','លុយ / មាស'],['土','ど / つち','ដី'],['山','さん / やま','ភ្នំ'],['川','せん / かわ','ទន្លេ'],['人','じん / ひと','មនុស្ស'],['大','だい / おおきい','ធំ'],['小','しょう / ちいさい','តូច'],['中','ちゅう / なか','កណ្ដាល'],['上','じょう / うえ','លើ'],['下','か / した','ក្រោម'],['学','がく / まなぶ','រៀន'],['生','せい / いきる','ជីវិត / កើត'],['先','せん / さき','មុន'],['本','ほん / もと','សៀវភៅ / ដើម'],['語','ご / かたる','ភាសា / និយាយ'],['食','しょく / たべる','បរិភោគ'],['見','けん / みる','មើល'],['行','こう / いく','ទៅ'],['来','らい / くる','មក'],['友','ゆう / とも','មិត្ត'],['年','ねん / とし','ឆ្នាំ'],['時','じ / とき','ពេលវេលា'],['国','こく / くに','ប្រទេស'],['車','しゃ / くるま','រថយន្ត'],['名','めい / な','ឈ្មោះ']
 ];
 let changed=false;
 for(const def of defs){
  if(db.books.some(b=>b.id===def.id))continue;
  const book={...def,volume:db.books.length+1,level:'EXTRA',free:false,words:[],lessons:[]};
  if(def.id==='sovann-dictionary-volume'){
   const coll=JSON.parse(fs.readFileSync(path.join(ROOT,'content','imported-vocabulary.json'),'utf8'));
   book.words=[...(coll.N5||[]),...(coll.N4||[])].map(w=>({...w,id:id()}));
   book.lessons=[{id:id(),title:'របៀបប្រើវចនានុក្រម',body:'ស្វែងរកដោយ Kanji / Hiragana / Romaji / ខ្មែរ។ ពាក្យដើមបាននាំចូលពី Word។ ពាក្យមានសញ្ញា ⚠ ត្រូវឱ្យ Admin ពិនិត្យជាមុន។'}];
  }else if(def.id==='sovann-grammar-volume'){
   book.lessons=grammar.map(([title,body])=>({id:id(),title,body}));
  }else{
   book.lessons=[{id:id(),title:'គោលការណ៍សរសេរកានជី',body:'ជាទូទៅសរសេរពីលើចុះក្រោម ពីឆ្វេងទៅស្តាំ ហើយចាប់ពីក្របក្រៅមុនផ្នែកខាងក្នុង។ ត្រូវហាត់តាមលំដាប់បន្ទាត់នៃអក្សរនីមួយៗ។'}];
   book.words=kanji.map(([kanji,reading,khmer])=>({id:id(),kanji,reading,romaji:'',khmer,example:'',translation:'',wordType:'Kanji · ការអានមានច្រើនអាស្រ័យលើពាក្យ'}));
  }
  db.books.push(book);changed=true;
 }
 if(changed)save();
}
seedThreeFocusedBooks();


// Optional initial admin provisioning: never ship a default password.
if(process.env.ADMIN_EMAIL&&process.env.ADMIN_PASSWORD){const email=clean(process.env.ADMIN_EMAIL,120).toLowerCase();if(!db.users.find(x=>x.email===email)){db.users.push({id:id(),name:'Sovan Sensei',email,password:hash(process.env.ADMIN_PASSWORD),role:'admin',walletCents:0,plan:'lifetime',expires:null,joined:iso()});save();console.log('Admin account created from environment.')}}
const rates=new Map();function limited(ip){const now=Date.now(),v=rates.get(ip)||{n:0,t:now};if(now-v.t>60000){v.n=0;v.t=now}v.n++;rates.set(ip,v);return v.n>80}
const response=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data))};
const fail=(res,status,message)=>response(res,status,{error:message});
const parseBody=req=>new Promise((resolve,reject)=>{let chunks=[],size=0;const maxSize=req.url.startsWith('/api/admin/upload')?2500000:req.url.startsWith('/api/community/image')?2100000:req.url.startsWith('/api/admin/words/bulk')?1200000:150000;req.on('data',b=>{size+=b.length;if(size>maxSize){reject(Error('សំណើធំពេក'));req.destroy();return}chunks.push(b)});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString()||'{}'))}catch{reject(Error('JSON invalid'))}});req.on('error',reject)});
function userFrom(req){let token=String(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('sovann_session='))?.split('=')[1];if(!token)return null;let sess=db.sessions.find(s=>s.tokenHash===crypto.createHash('sha256').update(token).digest('hex')&&s.until>Date.now());return sess?db.users.find(u=>u.id===sess.userId):null}
const safeUser=u=>u?{id:u.id,name:u.name,email:u.email,role:u.role,walletCents:u.walletCents,plan:u.plan,expires:u.expires,joined:u.joined,googleLinked:!!u.googleSub}:null;
function hasAccess(u,b){return b.free||u&&(u.role==='admin'||u.plan==='lifetime'||u.expires&&new Date(u.expires)>new Date())}
function auth(req,res){let u=userFrom(req);if(!u){fail(res,401,'សូមចូលគណនីមុន');return null}return u}
const requireAdmin=(req,res)=>{let u=auth(req,res);if(!u)return null;if(u.role!=='admin'){fail(res,403,'សម្រាប់ Admin ប៉ុណ្ណោះ');return null}return u};
const cents=x=>Math.round(Number(x)*100);
function adjust(u,amount,type,note){u.walletCents=Math.round((u.walletCents||0)+amount);db.walletTx.push({id:id(),userId:u.id,amountCents:amount,type,note,at:iso()})}
function expiresAfterMonths(months){const d=new Date();const day=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+months);const max=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,max));return d.toISOString()}
function issueSession(req,res,person){
 const token=crypto.randomBytes(32).toString('hex');
 db.sessions.push({tokenHash:crypto.createHash('sha256').update(token).digest('hex'),userId:person.id,until:Date.now()+14*86400000});
 db.sessions=db.sessions.filter(x=>x.until>Date.now());save();
 const tls=req.socket.encrypted||req.headers['x-forwarded-proto']==='https';
 res.setHeader('Set-Cookie',`sovann_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=1209600${tls?'; Secure':''}`);
}
// Google's tokeninfo endpoint verifies Google's signature and audience server-side.
// Use google-auth-library local JWT verification instead if high-volume production needs it.
async function verifyGoogle(credential){
 if(!process.env.GOOGLE_CLIENT_ID)throw Error('Google Login មិនទាន់កំណត់ Client ID');
 if(typeof credential!=='string'||credential.length>5000||credential.length<100)throw Error('Google token មិនត្រឹមត្រូវ');
 const result=await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+encodeURIComponent(credential),{signal:AbortSignal.timeout(8000)});
 if(!result.ok)throw Error('មិនអាចផ្ទៀងផ្ទាត់ Google បាន');
 const data=await result.json();
 if(data.aud!==process.env.GOOGLE_CLIENT_ID||!['accounts.google.com','https://accounts.google.com'].includes(data.iss)||data.email_verified!==true&&data.email_verified!=='true'||!data.sub||Number(data.exp)*1000<Date.now())throw Error('គណនី Google មិនត្រឹមត្រូវ');
 return {sub:String(data.sub),email:clean(data.email,120).toLowerCase(),name:clean(data.name||data.given_name||'Google Student',80)};
}
function imageBytes(raw){
 const m=typeof raw==='string'?raw.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/):null;
 if(!m||m[2].length>1800000)throw Error('សូមប្រើរូប JPG, PNG ឬ WEBP តូចជាង ១.២MB');
 const b=Buffer.from(m[2],'base64');
 if(b.length>1200000||b.length<16)throw Error('រូបភាពមិនត្រឹមត្រូវ ឬធំពេក');
 const jpg=b.subarray(0,3).toString('hex')==='ffd8ff';
 const png=b.subarray(0,8).toString('hex')==='89504e470d0a1a0a';
 const webp=b.subarray(0,4).toString()==='RIFF'&&b.subarray(8,12).toString()==='WEBP';
 const ext=jpg?'jpg':png?'png':webp?'webp':null;
 if(!ext||!(m[1]==='jpeg'&&ext==='jpg'||m[1]===ext))throw Error('មិនមែនឯកសាររូបភាពត្រឹមត្រូវ');
 return {bytes:b,ext};
}
function publicPost(post,u){
 const poster=db.users.find(x=>x.id===post.userId);
 return {id:post.id,author:poster?.name||'សមាជិក',mine:!!u&&post.userId===u.id,
  canDelete:!!u&&(u.role==='admin'||u.id===post.userId),
  text:post.text,image:post.image,created:post.created,
  liked:!!u&&post.likes.includes(u.id),likes:post.likes.length,commentCount:post.comments.length,
  comments:post.comments.slice(-30).map(c=>({id:c.id,text:c.text,created:c.created,
   author:db.users.find(x=>x.id===c.userId)?.name||'សមាជិក',canDelete:!!u&&(u.role==='admin'||c.userId===u.id||post.userId===u.id)}))};
}
function answerOffline(q){q=clean(q,2000).toLowerCase();const all=db.books.flatMap(b=>b.words||[]);const match=all.find(w=>[w.kanji,w.reading,w.romaji,w.khmer].some(v=>String(v||'').toLowerCase()===q));if(match)return `${match.kanji}（${match.reading}） — ${match.khmer}\nRomaji: ${match.romaji}`;if(q.includes('こんにちは'))return 'こんにちは = សួស្តី។ អានថា Konnichiwa។';if(q.includes('ありがとう'))return 'ありがとう = អរគុណ។ អានថា Arigatou។';if(q.includes('n5'))return 'N5 ជាកម្រិតដំបូង។ សូមចូលម៉ឺនុយ «សៀវភៅ» ហើយជ្រើស N5។';if(q.includes('តម្លៃ')||q.includes('price'))return 'គម្រោង ១ ខែ $2.50, ១ ឆ្នាំ $23.99, មួយជីវិត $35។';return 'ខ្ញុំជា Sovan AI (របៀបគំរូគ្មាន AI API)។ ខ្ញុំអាចរកពាក្យក្នុងវចនានុក្រម និងឆ្លើយសំណួរទូទៅមួយចំនួន។ ដើម្បីឆ្លើយសន្ទនាដោយ AI ឆ្លាតជាងនេះ ម្ចាស់វេបសាយត្រូវភ្ជាប់ AI service នៅ server។';}
async function route(req,res,url,body){let p=url.pathname,method=req.method,u=userFrom(req);
 if(p==='/api/bootstrap'&&method==='GET')return response(res,200,{books:db.books.map(({words,lessons,...b})=>({...b,wordCount:words.length,lessonCount:lessons.length,unlocked:!!hasAccess(u,b)})),products:db.products,config:db.config,user:safeUser(u),adminExists:db.users.some(x=>x.role==='admin'),googleClientId:process.env.GOOGLE_CLIENT_ID||'',aiConnected:!!(process.env.AI_API_KEY&&process.env.AI_BASE_URL&&process.env.AI_MODEL)});
 if(p==='/api/dictionary'&&method==='GET')return response(res,200,{words:db.books.filter(b=>hasAccess(u,b)).flatMap(b=>b.words||[])});
 if(p==='/api/book'&&method==='GET'){const b=db.books.find(b=>b.id===url.searchParams.get('id'));if(!b)return fail(res,404,'គ្មានសៀវភៅ');if(!hasAccess(u,b))return fail(res,403,'🔒 សូមជ្រើសគម្រោងសមាជិកភាព');return response(res,200,{book:b})}
 if(p==='/api/register'&&method==='POST'){
 const email=clean(body.email,120).toLowerCase(),password=String(body.password||''),name=clean(body.name,80);
 if(!name||!/^\S+@\S+\.\S+$/.test(email)||password.length<8)return fail(res,400,'ត្រូវបញ្ចូលឈ្មោះ អ៊ីមែល និងលេខសម្ងាត់យ៉ាងតិច ៨ តួ');
 if(db.users.some(x=>x.email===email))return fail(res,409,'អ៊ីមែលនេះមានគណនីរួច');
 const a={id:id(),name,email,password:hash(password),role:'student',walletCents:0,plan:'free',expires:null,joined:iso()};db.users.push(a);save();return response(res,201,{message:'ចុះឈ្មោះរួច សូម Log in'});
 }
 if(p==='/api/login'&&method==='POST'){
 const email=clean(body.email,120).toLowerCase(),pw=String(body.password||'');let a=db.users.find(x=>x.email===email);if(!a||!match(pw,a.password))return fail(res,401,'អ៊ីមែល ឬលេខសម្ងាត់មិនត្រឹមត្រូវ');
 const token=crypto.randomBytes(32).toString('hex');db.sessions.push({tokenHash:crypto.createHash('sha256').update(token).digest('hex'),userId:a.id,until:Date.now()+14*86400000});db.sessions=db.sessions.filter(s=>s.until>Date.now());save();
 res.setHeader('Set-Cookie',`sovann_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=1209600${req.socket.encrypted||req.headers['x-forwarded-proto']==='https'?'; Secure':''}`);return response(res,200,{user:safeUser(a)})}
 if(p==='/api/auth/google'&&method==='POST'){
  try{
   const g=await verifyGoogle(body.credential);
   // Owner identity is established by a verified Google identity token, not by a form field.
   // Configure ADMIN_GOOGLE_EMAIL only on the host; other Google accounts stay students.
   const ownerEmail=clean(process.env.ADMIN_GOOGLE_EMAIL||'',120).toLowerCase();
   const ownerLogin=!!ownerEmail&&g.email===ownerEmail;
   let person=db.users.find(x=>x.googleSub===g.sub);
   const emailAccount=db.users.find(x=>x.email===g.email);
   if(person&&emailAccount&&person.id!==emailAccount.id)return fail(res,409,'គណនី Google និងអ៊ីមែលនេះមានគណនីផ្សេងគ្នា សូមទាក់ទង Admin');
   if(ownerLogin){
    // A registration with this email may predate real Google verification.
    // Never promote its old password sessions to administrator privileges.
    if(!person){
     person=emailAccount;
     if(person&&person.googleSub&&person.googleSub!==g.sub)return fail(res,409,'Google email ត្រូវបានភ្ជាប់ទៅគណនីផ្សេងរួច');
     if(!person){
      person={id:id(),name:'Sovan Sensei',email:g.email,googleSub:g.sub,role:'admin',walletCents:0,plan:'lifetime',expires:null,joined:iso()};db.users.push(person);
     } else {
      const wasAdmin=person.role==='admin';
      person.googleSub=g.sub;person.role='admin';person.plan='lifetime';person.expires=null;
      if(!wasAdmin){person.password=null;db.sessions=db.sessions.filter(session=>session.userId!==person.id);}
     }
    } else if(person.role!=='admin'){
     person.role='admin';person.password=null;person.plan='lifetime';person.expires=null;
     db.sessions=db.sessions.filter(session=>session.userId!==person.id);
    }
    save();
   }else if(!person){
    if(emailAccount)return fail(res,409,'អ៊ីមែលនេះមានគណនីរួច។ សូម Log in តាមលេខសម្ងាត់សិន ដើម្បីភ្ជាប់ Google នៅក្នុង Profile។');
    person={id:id(),name:g.name,email:g.email,googleSub:g.sub,role:'student',walletCents:0,plan:'free',expires:null,joined:iso()};
    db.users.push(person);save();
   }
   issueSession(req,res,person);return response(res,200,{user:safeUser(person)});
  }catch(e){return fail(res,401,e.message)}
 }
 if(p==='/api/auth/google/link'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  try{
   const g=await verifyGoogle(body.credential);
   if(g.email!==u.email)return fail(res,403,'Google email ត្រូវតែដូចគណនីបច្ចុប្បន្ន');
   if(db.users.some(x=>x.googleSub===g.sub&&x.id!==u.id))return fail(res,409,'Google នេះភ្ជាប់នឹងគណនីផ្សេងហើយ');
   u.googleSub=g.sub;save();return response(res,200,{message:'Google បានភ្ជាប់ជាមួយគណនីនេះរួច'});
  }catch(e){return fail(res,401,e.message)}
 }
 if(p==='/api/community/feed'&&method==='GET'){
  const before=clean(url.searchParams.get('before'),40);
  const posts=db.posts.slice().reverse().filter(x=>!before||x.created<before).slice(0,30);
  return response(res,200,{posts:posts.map(x=>publicPost(x,u)),next:posts.length===30?posts.at(-1).created:null});
 }
 if(p==='/api/community/image'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  try{
   const {bytes,ext}=imageBytes(body.image),file=id()+'.'+ext;
   fs.writeFileSync(path.join(MEDIA,file),bytes,{flag:'wx',mode:0o600});
   const url='/media/'+file;
   db.media.push({url,userId:u.id,created:iso()});save();return response(res,200,{url});
  }catch(e){return fail(res,400,e.message)}
 }
 if(p==='/api/community/post'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  const text=clean(body.text,1500),image=clean(body.image,200);
  if(!text&&!image)return fail(res,400,'សូមសរសេរអត្ថបទ ឬដាក់រូបភាព');
  if(image&&!db.media.some(m=>m.url===image&&m.userId===u.id))return fail(res,400,'រូបភាពនេះមិនត្រូវនឹងគណនីបង');
  const recent=db.posts.filter(p=>p.userId===u.id&&Date.now()-Date.parse(p.created)<86400000);
  if(u.role!=='admin'&&recent.length>=15)return fail(res,429,'បងអាចបង្ហោះបាន ១៥ ប្រកាសក្នុងមួយថ្ងៃ');
  const post={id:id(),userId:u.id,text,image,likes:[],comments:[],created:iso()};
  db.posts.push(post);save();return response(res,201,{post:publicPost(post,u)});
 }
 if(p==='/api/community/like'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  const post=db.posts.find(x=>x.id===body.id);if(!post)return fail(res,404,'រកមិនឃើញប្រកាស');
  const n=post.likes.indexOf(u.id);if(n<0)post.likes.push(u.id);else post.likes.splice(n,1);
  save();return response(res,200,{liked:post.likes.includes(u.id),likes:post.likes.length});
 }
 if(p==='/api/community/comment'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  const post=db.posts.find(x=>x.id===body.id),text=clean(body.text,500);
  if(!post)return fail(res,404,'រកមិនឃើញប្រកាស');if(!text)return fail(res,400,'សូមសរសេរមតិ');
  if(post.comments.filter(c=>c.userId===u.id&&Date.now()-Date.parse(c.created)<3600000).length>=20)return fail(res,429,'មតិច្រើនពេកក្នុងមួយម៉ោង');
  post.comments.push({id:id(),userId:u.id,text,created:iso()});save();return response(res,201,{message:'បានបញ្ចូលមតិ'});
 }
 if(p==='/api/community/delete'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  const post=db.posts.find(x=>x.id===body.id);if(!post)return fail(res,404,'រកមិនឃើញប្រកាស');
  if(post.userId!==u.id&&u.role!=='admin')return fail(res,403,'គ្មានសិទ្ធិលុប');
  db.posts=db.posts.filter(x=>x.id!==post.id);save();return response(res,200,{message:'បានលុបប្រកាស'});
 }
 if(p==='/api/community/comment/delete'&&method==='POST'){
  if(!(u=auth(req,res)))return;
  const post=db.posts.find(x=>x.id===body.id),comment=post?.comments.find(x=>x.id===body.commentId);
  if(!comment)return fail(res,404,'រកមិនឃើញមតិ');
  if(u.role!=='admin'&&u.id!==post.userId&&u.id!==comment.userId)return fail(res,403,'គ្មានសិទ្ធិលុប');
  post.comments=post.comments.filter(x=>x.id!==comment.id);save();return response(res,200,{message:'បានលុបមតិ'});
 }
 if(p==='/api/logout'&&method==='POST'){const cookie=String(req.headers.cookie||'').match(/sovann_session=([^;]+)/);if(cookie)db.sessions=db.sessions.filter(s=>s.tokenHash!==crypto.createHash('sha256').update(cookie[1]).digest('hex'));res.setHeader('Set-Cookie','sovann_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0');save();return response(res,200,{message:'ចាកចេញរួច'})}
 if(p==='/api/wallet/topup'&&method==='POST'){if(!(u=auth(req,res)))return;let amount=Number(body.amount);if(!Number.isFinite(amount)||amount<1||amount>500)return fail(res,400,'អាចដាក់ចន្លោះ $1–$500');const rec={id:id(),userId:u.id,amountCents:cents(amount),reference:clean(body.reference,120),status:'pending',created:iso()};db.topups.push(rec);save();return response(res,200,{topup:rec,message:'សំណើបានផ្ញើទៅ Admin។ Credit មិនទាន់បញ្ចូលទេ។'})}
 if(p==='/api/wallet/history'&&method==='GET'){if(!(u=auth(req,res)))return;return response(res,200,{topups:db.topups.filter(t=>t.userId===u.id).slice(-80).reverse(),transactions:db.walletTx.filter(t=>t.userId===u.id).slice(-80).reverse(),orders:db.orders.filter(t=>t.userId===u.id).slice(-30).reverse()})}
 if(p==='/api/membership/buy'&&method==='POST'){
 if(!(u=auth(req,res)))return;const key=clean(body.plan,30),valid=['monthly','yearly','lifetime'];if(!valid.includes(key))return fail(res,400,'គម្រោងមិនត្រឹមត្រូវ');const cost=cents(db.config.prices[key]);if(u.walletCents<cost)return fail(res,400,'Credit មិនគ្រប់។ សូមដាក់ប្រាក់ជាមុន');
 adjust(u,-cost,'membership','សមាជិកភាព '+key);u.plan=key;u.expires=key==='lifetime'?null:expiresAfterMonths(key==='monthly'?1:12);save();return response(res,200,{user:safeUser(u),message:'ទិញគម្រោងបានជោគជ័យ'});
 }
 if(p==='/api/shop/buy'&&method==='POST'){
 if(!(u=auth(req,res)))return;let list=Array.isArray(body.items)?body.items:[];if(!list.length||list.length>30)return fail(res,400,'គ្មានទំនិញ');let units=[],total=0;for(const it of list){let pr=db.products.find(p=>p.id===it.id),qty=Number(it.qty);if(!pr||!Number.isInteger(qty)||qty<1||qty>50||pr.stock<qty)return fail(res,400,'ទំនិញ ឬស្តុកមិនត្រឹមត្រូវ');units.push({id:pr.id,name:pr.name,qty,price:pr.price});total+=cents(pr.price)*qty}if(u.walletCents<total)return fail(res,400,'Credit មិនគ្រប់');units.forEach(it=>db.products.find(p=>p.id===it.id).stock-=it.qty);adjust(u,-total,'shop','ទិញទំនិញ');db.orders.push({id:id(),userId:u.id,items:units,totalCents:total,at:iso(),status:'new'});save();return response(res,200,{message:'បញ្ជាទិញបានកត់ត្រា សូមទាក់ទង Admin សម្រាប់ការដឹកជញ្ជូន',user:safeUser(u)})}
 if(p==='/api/chat'&&method==='GET'){if(!(u=auth(req,res)))return;const peer=u.role==='admin'?clean(url.searchParams.get('peer'),80):'admin';const admin=db.users.find(a=>a.role==='admin');if(!admin)return response(res,200,{messages:[],contacts:[]});const target=peer==='admin'?admin.id:peer;let msgs=db.chats.filter(c=>(c.from===u.id&&c.to===target)||(c.to===u.id&&c.from===target)).slice(-150);let contacts=u.role==='admin'?db.users.filter(a=>a.role==='student').map(s=>({id:s.id,name:s.name})):[];return response(res,200,{messages:msgs,contacts})}
 if(p==='/api/chat'&&method==='POST'){if(!(u=auth(req,res)))return;const msg=clean(body.message,1500);if(!msg)return fail(res,400,'សូមវាយសារ');const admin=db.users.find(a=>a.role==='admin');const to=u.role==='admin'?clean(body.to,80):admin?.id;if(!to||!db.users.some(a=>a.id===to))return fail(res,400,'គ្មានអ្នកទទួល');db.chats.push({id:id(),from:u.id,to,text:msg,at:iso()});if(db.chats.length>10000)db.chats.splice(0,2000);save();return response(res,200,{message:'ផ្ញើរួច'})}
 if(p==='/api/ai/chat'&&method==='POST'){
 if(!(u=auth(req,res)))return;const q=clean(body.message,1500);if(!q)return fail(res,400,'សូមវាយសំណួរ');
 if(process.env.AI_API_KEY&&process.env.AI_BASE_URL&&process.env.AI_MODEL){try{let endpoint=process.env.AI_BASE_URL.replace(/\/$/,'')+'/chat/completions';let c=AbortSignal.timeout(18000);const reply=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+process.env.AI_API_KEY},body:JSON.stringify({model:process.env.AI_MODEL,messages:[{role:'system',content:'You are Sovan AI, a helpful Japanese learning assistant. Reply in the user language (Khmer or Japanese as appropriate); avoid inventing JLPT facts. Be concise.'},{role:'user',content:q}],max_tokens:600}),signal:c});if(reply.ok){let j=await reply.json();return response(res,200,{reply:clean(j.choices?.[0]?.message?.content,4000),mode:'ai'})}}catch(e){console.error('AI service:',e.message)}}
 return response(res,200,{reply:answerOffline(q),mode:'demo'})}
 if(p==='/api/admin/overview'&&method==='GET'){if(!requireAdmin(req,res))return;return response(res,200,{users:db.users.map(safeUser),topups:db.topups.slice().reverse(),orders:db.orders.slice().reverse(),config:db.config})}
 if(p==='/api/admin/topup'&&method==='POST'){if(!requireAdmin(req,res))return;const r=db.topups.find(t=>t.id===body.id);if(!r||r.status!=='pending')return fail(res,400,'សំណើត្រូវបានដោះស្រាយរួច');const action=clean(body.action,20);if(!['approve','reject'].includes(action))return fail(res,400,'សកម្មភាពមិនត្រឹមត្រូវ');const person=db.users.find(u=>u.id===r.userId);if(!person)return fail(res,404,'គ្មានគណនីសិស្ស');r.status=action==='approve'?'approved':'rejected';r.reviewed=iso();if(action==='approve')adjust(person,r.amountCents,'topup','Admin បានបញ្ជាក់ថាប្រាក់ចូល ABA ពិត');save();return response(res,200,{message:'បានធ្វើបច្ចុប្បន្នភាព'})}
 if(p==='/api/admin/book'&&method==='POST'){if(!requireAdmin(req,res))return;const b=db.books.find(b=>b.id===clean(body.id,40));if(!b)return fail(res,404,'គ្មានសៀវភៅ');for(const k of ['title','subtitle','description'])if(body[k]!==undefined)b[k]=clean(body[k],2000);if(body.coverUrl!==undefined){const a=clean(body.coverUrl,500);if(!a||a.startsWith('/assets/uploads/')||/^https:\/\/[^ ]+$/i.test(a))b.coverUrl=a;else return fail(res,400,'Cover URL must be https or an uploaded image')}if(typeof body.free==='boolean')b.free=body.free;save();return response(res,200,{message:'កែសៀវភៅរួច'})}
 if(p==='/api/admin/upload'&&method==='POST'){if(!requireAdmin(req,res))return;const m=String(body.image||'').match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);if(!m)return fail(res,400,'រូបភាពមិនត្រឹមត្រូវ');const data=Buffer.from(m[2],'base64');if(data.length>1500000||data.length<100||!(data.subarray(0,3).toString('hex')==='ffd8ff'||data.subarray(0,8).toString('hex')==='89504e470d0a1a0a'||data.subarray(0,4).toString()==='RIFF'))return fail(res,400,'ទ្រង់ទ្រាយ ឬទំហំរូបភាពមិនត្រឹមត្រូវ');const ext=m[1]==='jpeg'?'jpg':m[1],dir=path.join(PUBLIC,'assets','uploads');fs.mkdirSync(dir,{recursive:true});const fn=id()+'.'+ext;fs.writeFileSync(path.join(dir,fn),data);return response(res,200,{url:'/assets/uploads/'+fn})}
 if(p==='/api/admin/book/new'&&method==='POST'){if(!requireAdmin(req,res))return;const title=clean(body.title,150),subtitle=clean(body.subtitle,150),level=clean(body.level,15)||'EXTRA';if(!title||!subtitle||db.books.length>100)return fail(res,400,'ព័ត៌មានសៀវភៅមិនត្រឹមត្រូវ');const b={id:id(),title,subtitle,level,volume:db.books.length+1,free:false,color:'#9653bd',description:'សៀវភៅថ្មីដែល Admin បានបង្កើត',words:[],lessons:[]};db.books.push(b);save();return response(res,200,{message:'បានបន្ថែមសៀវភៅថ្មី'})}
 if(p==='/api/admin/words/bulk'&&method==='POST'){if(!requireAdmin(req,res))return;let b=db.books.find(a=>a.id===clean(body.bookId,40));if(!b)return fail(res,404,'គ្មានសៀវភៅ');let rows=String(body.lines||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(rows.length>1000||rows.length<1)return fail(res,400,'សូមបញ្ចូល 1–1000 បន្ទាត់ក្នុងមួយលើក');const words=[];const seen=new Set(b.words.map(w=>w.kanji+'|'+w.reading));let skipped=0;for(const row of rows){let parts=row.split('|').map(x=>clean(x,300));if(parts.length<4||!parts[0]||!parts[3])return fail(res,400,'ទម្រង់ត្រូវជា Kanji|Hiragana|Romaji|Khmer មួយបន្ទាត់មួយពាក្យ');const k=parts[0]+'|'+parts[1];if(seen.has(k)){skipped++;continue}seen.add(k);words.push({id:id(),kanji:parts[0],reading:parts[1],romaji:parts[2],khmer:parts[3],example:parts[4]||'',translation:parts[5]||''})}b.words.push(...words);save();return response(res,200,{message:'បន្ថែម '+words.length+' ពាក្យរួច (រំលងស្ទួន '+skipped+')'})}
 if(p==='/api/admin/word/edit'&&method==='POST'){if(!requireAdmin(req,res))return;let b=db.books.find(a=>a.id===body.bookId),w=b?.words.find(w=>w.id===body.wordId);if(!w)return fail(res,404,'មិនឃើញពាក្យ');for(const k of ['kanji','reading','romaji','khmer','example','translation'])if(body[k]!==undefined)w[k]=clean(body[k],300);save();return response(res,200,{message:'កែពាក្យរួច'})}
 if(p==='/api/admin/word'&&method==='POST'){if(!requireAdmin(req,res))return;const b=db.books.find(b=>b.id===clean(body.bookId,40));if(!b)return fail(res,404,'គ្មានសៀវភៅ');const w={id:id(),kanji:clean(body.kanji,60),reading:clean(body.reading,100),romaji:clean(body.romaji,100),khmer:clean(body.khmer,150),example:clean(body.example,300),translation:clean(body.translation,300)};if(!w.kanji||!w.khmer)return fail(res,400,'ត្រូវបំពេញពាក្យ និងអត្ថន័យខ្មែរ');b.words.push(w);save();return response(res,200,{message:'បានបន្ថែមពាក្យសព្ទ'})}
 if(p==='/api/admin/word/delete'&&method==='POST'){if(!requireAdmin(req,res))return;const b=db.books.find(b=>b.id===clean(body.bookId,40));if(!b)return fail(res,404,'គ្មានសៀវភៅ');b.words=b.words.filter(w=>w.id!==body.wordId);save();return response(res,200,{message:'បានលុបពាក្យ'})}
 if(p==='/api/admin/lesson'&&method==='POST'){if(!requireAdmin(req,res))return;const b=db.books.find(b=>b.id===clean(body.bookId,40));if(!b)return fail(res,404,'គ្មានសៀវភៅ');const title=clean(body.title,150),text=clean(body.body,9000);if(!title||!text)return fail(res,400,'ត្រូវបំពេញចំណងជើង និងមេរៀន');b.lessons.push({id:id(),title,body:text});save();return response(res,200,{message:'បានបន្ថែមមេរៀន'})}
 if(p==='/api/admin/config'&&method==='POST'){if(!requireAdmin(req,res))return;for(const k of ['brand','classHours','teacher','about','videoRoom','paywayLink'])if(body[k]!==undefined)db.config[k]=clean(body[k],2000);if(body.prices){for(const k of ['monthly','yearly','lifetime']){let value=Number(body.prices[k]);if(Number.isFinite(value)&&value>=0&&value<1000)db.config.prices[k]=Math.round(value*100)/100}}save();return response(res,200,{message:'កែការកំណត់រួច'})}
 if(p==='/api/admin/product'&&method==='POST'){if(!requireAdmin(req,res))return;let price=Number(body.price),stock=Number(body.stock);if(!clean(body.name)||!Number.isFinite(price)||price<0||price>10000||!Number.isInteger(stock)||stock<0)return fail(res,400,'ព័ត៌មានទំនិញមិនត្រឹមត្រូវ');db.products.push({id:id(),name:clean(body.name,100),price:Math.round(price*100)/100,stock,emoji:clean(body.emoji,8)||'🛍️'});save();return response(res,200,{message:'បានបន្ថែមទំនិញ'})}
 if(p==='/api/admin/user/plan'&&method==='POST'){if(!requireAdmin(req,res))return;let target=db.users.find(a=>a.id===body.userId);if(!target||target.role==='admin')return fail(res,400,'គណនីមិនត្រឹមត្រូវ');let plan=clean(body.plan,20);if(!['free','monthly','yearly','lifetime'].includes(plan))return fail(res,400,'គម្រោងមិនត្រឹមត្រូវ');target.plan=plan;target.expires=plan==='monthly'?expiresAfterMonths(1):plan==='yearly'?expiresAfterMonths(12):null;save();return response(res,200,{message:'បានកំណត់សិទ្ធិសិស្ស'})}
 if(p==='/api/admin/export'&&method==='GET'){if(!requireAdmin(req,res))return;return response(res,200,{books:db.books,products:db.products,config:db.config,users:db.users.map(safeUser),topups:db.topups,orders:db.orders});}
 return fail(res,404,'API មិនមាន');
}
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.webp':'image/webp'};
const server=http.createServer(async(req,res)=>{
 try{
 let u=new URL(req.url,'http://localhost');if(limited(req.socket.remoteAddress||'unknown'))return fail(res,429,'សំណើច្រើនពេក សូមរង់ចាំបន្តិច');
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');
 if(u.pathname.startsWith('/api/')){
 if(!['GET','POST'].includes(req.method))return fail(res,405,'Method not allowed');
 if(req.method==='POST'){
 // Browser cross-site POSTs are rejected; deploy under one origin.
 const origin=req.headers.origin;const host=req.headers.host;
 if(origin){const allowed=process.env.PUBLIC_URL?new URL(process.env.PUBLIC_URL).origin:null;let origHost=new URL(origin).host;if(origHost!==host&&origin!==allowed)return fail(res,403,'Origin not allowed')}
 }
 let body=req.method==='POST'?await parseBody(req):{};return await route(req,res,u,body)}
 if(u.pathname.startsWith('/media/')){
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end()}
  const name=u.pathname.slice('/media/'.length);
  if(!/^[0-9a-f-]{36}\.(jpg|png|webp)$/.test(name)){res.writeHead(404);return res.end()}
  const file=path.join(MEDIA,name);if(!fs.existsSync(file)){res.writeHead(404);return res.end()}
  const mime=name.endsWith('.jpg')?'image/jpeg':name.endsWith('.png')?'image/png':'image/webp';
  res.writeHead(200,{'Content-Type':mime,'Cache-Control':'public, max-age=3600','X-Content-Type-Options':'nosniff'});
  if(req.method==='HEAD')return res.end();return fs.createReadStream(file).pipe(res)
 }
 if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end()}
 let uri=decodeURIComponent(u.pathname);if(uri==='/'||!path.extname(uri))uri='/index.html';const file=path.resolve(PUBLIC,'.'+uri);if(!file.startsWith(PUBLIC+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);return res.end('Not found')}
 res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','Cache-Control':uri.endsWith('index.html')?'no-cache':'public, max-age=3600'});if(req.method==='HEAD')return res.end();fs.createReadStream(file).pipe(res)
 }catch(e){console.error(e.message);if(!res.headersSent)fail(res,400,'បញ្ហាទិន្នន័យ / '+e.message)}
});server.listen(PORT,'0.0.0.0',()=>console.log('Sovann Library http://localhost:'+PORT));
