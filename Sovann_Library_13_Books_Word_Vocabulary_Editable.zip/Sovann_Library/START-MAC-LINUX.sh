#!/bin/sh
printf 'Admin email (first run only): '
read ADMIN_EMAIL
printf 'Admin password: '
stty -echo
read ADMIN_PASSWORD
stty echo
printf '\n'
export ADMIN_EMAIL ADMIN_PASSWORD
node server.js
